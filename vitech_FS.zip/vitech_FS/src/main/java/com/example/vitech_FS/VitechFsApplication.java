package com.example.vitech_FS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitechFsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VitechFsApplication.class, args);
	}

}
