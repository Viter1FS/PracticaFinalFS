package com.example.vitech_FS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitechFsApplicationTests {

	@Test
	void contextLoads() {
	}

}
